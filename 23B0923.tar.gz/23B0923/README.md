#### Dependencies:
- g++
- make
- SFML

#### Running instructions:
- To run `main.cpp` (my test code): `make`
- To clean all binaries: `make clean` 
  